import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.GroupLayout;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.EmptyBorder;

public class DialogBox  extends JDialog {
	private static final long serialVersionUID = 7079896468919174314L;
	private final JPanel contentPanel = new JPanel();
	
	public static void main(String[] args) {
		try {
			DialogBox dialog = new DialogBox();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public DialogBox() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("files/icon.png"));
		setBounds(100, 100, 600, 450);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JTextArea diagBoxText = new JTextArea();
		diagBoxText.setFont(new Font("Calibri", Font.PLAIN, 15));
		diagBoxText.setWrapStyleWord(true);
		diagBoxText.setEditable(false);
		diagBoxText.setLineWrap(true);

		if (MainClass.diagBoxType.equals("Help"))
			diagBoxText.setText("Help\n\nThis project is still not completed. Please Email your questions and comments to me at:\nvargha@Email.com");
		else if (MainClass.diagBoxType.equals("About"))
			diagBoxText.setText("About PersonalTaskOrganizer\n\nThis program is a simple and an easy to use task organizer written in Java. \nIt can be a good help for students to manage homework for different classes. \nEach task can has its own due date and priority. It is also possible to sort\ntask based on:\n  - Task Class\n  - Task Name\n  - Due Date\n  - Priority\nYou can also print the task list, and add a task to the list, or remove a task\nfrom it. It uses a simple XML database to store data.");
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(diagBoxText)
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(diagBoxText, GroupLayout.PREFERRED_SIZE, 251, Short.MAX_VALUE)
		);
		contentPanel.setLayout(gl_contentPanel);
	}




}
