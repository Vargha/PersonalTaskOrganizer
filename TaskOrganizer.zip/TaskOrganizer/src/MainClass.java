import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import com.toedter.calendar.JDateChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JCheckBox;


public class MainClass {
	private static JTextField classField;
	private static JTextField taskField;
	private static JTextField priorityField;
    public static String diagBoxType="V", dbLink="files/TaskOrganizerDB";
    public static Object taskRows[][];
    public static TableModel model;
    static JFrame frame;
    static int[] selectedRows;
    static JTable table;
    static int colNum = 4;
	static Object viewRows[][];
	
    public static void main(String args[]) {
    	frame = new JFrame("Task Manager");
	    frame.setIconImage(Toolkit.getDefaultToolkit().getImage("files/icon.png"));
	    frame.setResizable(false);
	    
	    //------------------ Menu Starts
	    JMenu file, dbManager;
	    JMenuItem emptyTable, deleteOverdue, backupDB, help, about, quit;
	    JMenuBar mb=new JMenuBar();
	    
	    file = new JMenu("File");
	    dbManager = new JMenu("Database manager");

	    emptyTable = new JMenuItem("EMPTY TABLE");
	    emptyTable.setForeground(new Color(165, 0, 0));
	    backupDB = new JMenuItem("Backup database");
	    deleteOverdue = new JMenuItem("Delete Overdue");
	    
	    help = new JMenuItem("Help");
	    help.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseReleased(MouseEvent e) {
	    		diagBoxType = "Help";
	    		DialogBox dialogBox = new DialogBox();
				dialogBox.setVisible(true);
	    	}
	    });
	    
	    about = new JMenuItem("About");
	    about.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseReleased(MouseEvent e) {
	    		diagBoxType = "About";
	    		DialogBox dialogBox = new DialogBox();
				dialogBox.setVisible(true);
	    	}
	    });
	    quit = new JMenuItem("Quit");
	    
	    dbManager.add(backupDB); dbManager.add(deleteOverdue); dbManager.add(emptyTable);
	    file.add(dbManager); file.add(about); file.add(help); file.add(quit);
	    mb.add(file);
	    frame.setJMenuBar(mb);
	
	    quit.addMouseListener(new MouseAdapter() {				// When quit gets clicked
			@Override
			public void mouseReleased(MouseEvent arg0) {
				System.exit(0);									// Quit the program				
			}
		});
	    //------------------ Menu Ends
	    
	    //------------------ Table Starts
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    
	    File taskDB = new File(dbLink);
	    Object taskRows[][];
	    taskRows = new Object[1000][4];
	    readDB(taskDB, taskRows);
	    /* Specify column names */
	    String columns[] = { "Class", "Task", "Due Date", "Priority"};

	    createTable(taskRows, columns);	    // Create a TableModel
	    //------------------ Table Ends
	    
	    JLabel lblAddTask = new JLabel("Add a New Task");
	    lblAddTask.setForeground(new Color(0, 100, 0));
	    lblAddTask.setFont(new Font("Tahoma", Font.BOLD, 12));
	    lblAddTask.setBounds(10, 276, 130, 20);
	    frame.getContentPane().add(lblAddTask);
	    
	    JLabel lblClass = new JLabel("Class:");
	    lblClass.setBounds(10, 300, 46, 14);
	    frame.getContentPane().add(lblClass);
	    
	    classField = new JTextField();
	    classField.setBounds(10, 325, 130, 20);
	    frame.getContentPane().add(classField);
	    classField.setColumns(10);
	    
	    JLabel lblTask = new JLabel("Task:");
	    lblTask.setBounds(157, 300, 46, 14);
	    frame.getContentPane().add(lblTask);
	    
	    taskField = new JTextField();
	    taskField.setBounds(157, 325, 130, 20);
	    frame.getContentPane().add(taskField);
	    taskField.setColumns(10);
	    
	    JLabel lblDueDate = new JLabel("Due Date:");
	    lblDueDate.setBounds(299, 300, 68, 14);
	    frame.getContentPane().add(lblDueDate);
	    
	    JLabel lblPriority = new JLabel("Priority:");
	    lblPriority.setBounds(448, 300, 46, 14);
	    frame.getContentPane().add(lblPriority);
	    
	    priorityField = new JTextField();
	    priorityField.setBounds(448, 325, 126, 20);
	    frame.getContentPane().add(priorityField);
	    priorityField.setColumns(10);
	    
	    JDateChooser dueDatePicker = new JDateChooser();
	    dueDatePicker.setBounds(297, 325, 141, 20);
	    frame.getContentPane().add(dueDatePicker);
	    
	    JButton btnAddTask = new JButton("Add Task");
	    btnAddTask.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseReleased(MouseEvent arg0) {
	    		SimpleDateFormat format1 = new SimpleDateFormat("YYYY/MM/dd");
				Object newTask[] = {
	    				classField.getText(),
	    				taskField.getText(),
	    				format1.format(dueDatePicker.getDate()),
	    				priorityField.getText()
	    		};
	    		try {
					appendTaskToDB(newTask);
				} catch (IOException e) { e.printStackTrace(); }
	    	}
	    });
	    btnAddTask.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    	}
	    });
	    btnAddTask.setBounds(10, 356, 564, 23);
	    frame.getContentPane().add(btnAddTask);
	    
	    JButton btnPrintTasks = new JButton("Print Tasks");
	    btnPrintTasks.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		try {
	    			MessageFormat header = new MessageFormat("Page {0,number,integer}");
	    		    table.print(JTable.PrintMode.FIT_WIDTH, header, null); 
	    		} catch (java.awt.print.PrinterException e) {
	    		     System.err.format("Cannot print %s%n", e.getMessage()); 
	    		}
	    	}
	    });
	    btnPrintTasks.setBounds(10, 242, 130, 23);
	    frame.getContentPane().add(btnPrintTasks);
	    
	    // ------ Delete Task
	    JButton btnDeleteTask = new JButton("Delete Task");
	    btnDeleteTask.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		Object[][] newViewRows = new Object[viewRows.length-selectedRows.length][colNum]; 
	    		for (int sr=0; sr<selectedRows.length; sr++){	// for each item in selected rows
	    			for (int vr=0; vr<viewRows.length; vr++){	// Move over all task rows
	    				int compareFlag = 0;
	    				for (int col=0; col<colNum; col++){		// Move over all columns and compare
	    					if (table.getValueAt(selectedRows[sr], col).equals(viewRows[vr][col])){
		    					//System.out.println(viewRows[vr][col]);
	    						compareFlag++;
		    				}
	    				}
	    				if (compareFlag == colNum){				// if all the columns are equal
	    					for (int i=vr; i<viewRows.length-1; i++){ // Move all the next rows up one level
	    						for (int j=0; j<colNum; j++){
	    							//viewRows[i][j] = viewRows[i+1][j];
	    							newViewRows[i][j] = viewRows[i+1][j];
	    						}
	    					}
	    				}
	    			}
	    		} // Now the new task list is ready
	    		// --- Write to file
	    		try {
					writeNewDB(newViewRows);
					JOptionPane.showMessageDialog(null, "Delete was successfull. Exiting the program.");
					System.exit(10);	// This is a temp fix to deal with list renew problem. I cannot write over viewRows because it is static ***
				} catch (IOException e) { e.printStackTrace(); }
	    		// --- Renew the List
	    	}
	    });
	    btnDeleteTask.setBounds(157, 242, 130, 23);
	    frame.getContentPane().add(btnDeleteTask);
	    
	    JButton btnQuit = new JButton("Quit");
	    btnQuit.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseReleased(MouseEvent arg0) {
	    		System.exit(0);									// Quit the program
	    	}
	    });
	    btnQuit.setFont(new Font("Tahoma", Font.BOLD, 11));
	    btnQuit.setForeground(new Color(255, 255, 255));
	    btnQuit.setBackground(new Color(128, 0, 0));
	    btnQuit.setBounds(448, 242, 126, 23);
	    frame.getContentPane().add(btnQuit);
	    
	    JSeparator separator = new JSeparator();
	    separator.setBounds(10, 276, 564, 2);
	    frame.getContentPane().add(separator);
	    
	    //JCheckBox chckbxHideOverdueTasks = new JCheckBox("Hide Overdue Tasks");
	    //chckbxHideOverdueTasks.setBounds(299, 242, 139, 23);
	    //frame.getContentPane().add(chckbxHideOverdueTasks);
	
	    frame.setSize(600, 454);
	    frame.setVisible(true);
    }
    
    // ---------- write tasks into the database
    protected static void writeNewDB(Object[][] newViewRows) throws IOException {
    	File dbFile = new File(dbLink);
    	try {
			FileOutputStream fos = new FileOutputStream(dbFile);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write("<Tasks>\n");
			for (int r=0; r<viewRows.length-1; r++){
				String tsk = 
				"\t<TaskItem>\n"+ 
    		    		"\t\t<Class>\n" + newViewRows[r][0] + "\n\t\t</Class>\n" +
    		    		"\t\t<Task>\n" + newViewRows[r][1] + "\n\t\t</Task>\n" +
    		    		"\t\t<DueDate>\n" + newViewRows[r][2] + "\n\t\t</DueDate>\n" +
    		    		"\t\t<Priority>\n" + newViewRows[r][3] + "\n\t\t</Priority>\n" +
    		    "\t</TaskItem>\n";
				bw.write(tsk);
			}
			bw.write("</Tasks>");
			bw.close();
		} catch (FileNotFoundException e) { e.printStackTrace(); }
	}

	private static void createTable(Object[][] taskRows, String[] columns) {
    	int rowCount = countRows(taskRows);
    	viewRows = new Object[rowCount][4];
    	for (int i=0; i<rowCount; i++)
    		for (int j=0; j<4; j++)
    		viewRows[i][j] = taskRows[i][j];
    	model = new DefaultTableModel(viewRows, columns) {
			private static final long serialVersionUID = 1L;
			public Class<?> getColumnClass(int column) {
		        Class<?> returnValue;
		        if ((column >= 0) && (column < getColumnCount())) {
		          returnValue = getValueAt(0, column).getClass();
		        } else {
		          returnValue = Object.class;
		        }
		        return returnValue;
			}
	    };
	    table = new JTable(model);
		
	    RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(model);
	    frame.getContentPane().setLayout(null);
	
	    table.setRowSorter(sorter);
	
	    JScrollPane pane = new JScrollPane(table);
	    pane.setBounds(0, 0, 584, 231);
	    frame.getContentPane().add(pane);
	    
	    // ---------- Selection Listener
	    table.setRowSelectionAllowed(true);
	    ListSelectionModel cellSelectionModel = table.getSelectionModel();
	    table.setRowSelectionAllowed(true);
	    table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

	    cellSelectionModel.addListSelectionListener(new ListSelectionListener() {
	        public void valueChanged(ListSelectionEvent e) {
	          selectedRows = table.getSelectedRows();		// Store the selected rows in a temp array
	          //System.out.println("Delete Task"+table.getValueAt(selectedRows[0], 0));
	        }

	      });
	    
	}

	private static int countRows(Object[][] taskRows2) {
		int i=0;
		while (taskRows2[i][0]!=null && taskRows2[i][1]!=null && taskRows2[i][2]!=null && taskRows2[i][3]!=null)
			i++;
		return i;
	}

	// ---------- Read data from the Database file and write into the table
	private static void readDB(File taskDB, Object taskRows[][]) {
		int i=0;
		try {
		Scanner scanner = new Scanner(taskDB);
		while (scanner.hasNextLine()) {
			String className="", taskName="", dueDate="", priority="0", tempLine=scanner.nextLine();
			//int priority=0;
			if (tempLine.contains("<Class>")){
				className = scanner.nextLine();
				taskRows[i][0]=className;	//Append data to the end of the array
				scanner.nextLine();
			}
			if (tempLine.contains("<Task>")){
				taskName = scanner.nextLine();
				taskRows[i][1]=taskName;	//Append data to the end of the array
			}
			if (tempLine.contains("<DueDate>")){
				dueDate = scanner.nextLine();
				taskRows[i][2]=dueDate;	//Append data to the end of the array
			}
			if (tempLine.contains("<Priority>")){
				//priority = scanner.nextInt();
				priority = scanner.nextLine();
				taskRows[i][3]=priority;	//Append data to the end of the array
				i++;
			}
			
		}
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	// --------- Append Task to DB 
	protected static void appendTaskToDB(Object[] newTask) throws IOException {
		String db = "files/TaskOrganizerDB";
		List<String> newLines = new ArrayList<>();
		for (String line : Files.readAllLines(Paths.get(db), StandardCharsets.UTF_8)) {
		    if (line.contains("</Tasks>")) {
		       newLines.add(line.replace("</Tasks>",
		    		    "\t<TaskItem>\n"+ 
		    		    		"\t\t<Class>\n\t\t\t" + newTask[0] + "\n\t\t</Class>\n" +
		    		    		"\t\t<Task>\n\t\t\t" + newTask[1] + "\n\t\t</Task>\n" +
		    		    		"\t\t<DueDate>\n\t\t\t" + newTask[2] + "\n\t\t</DueDate>\n" +
		    		    		"\t\t<Priority>\n\t\t\t" + newTask[3] + "\n\t\t</Priority>\n" +
		    		    "\t</TaskItem>\n" + "</Tasks>"));
		    } else {
		       newLines.add(line);
		    }
		}
		Files.write(Paths.get(db), newLines, StandardCharsets.UTF_8);
		

		File taskDB = new File("files/TaskOrganizerDB");
	    Object taskRows[][];
	    taskRows = new Object[1000][4];
	    readDB(taskDB, taskRows);
	    /* Specify column names */
	    String columns[] = { "Class", "Task", "Due Date", "Priority"};
	    createTable(taskRows, columns);	    // Create a TableModel
	}
}